# labirynth_ai_project
This program lets you generate labyrinths with parametrization of:
- how long the paths should be
- precentage of walls to remove
- size of labitynth
- cell size
- the end point to be in a random position (default: right bottom corner) 



additionally this program allows you to find the shortest path in the labirynth from one cell to another using pathfinding algorithms:
- dfs
- bfs
- a*
- dijkstra


co-creator : https://github.com/TomaszDaruk

see it in action: https://youtube.com/shorts/NVU29nldKMc?feature=share
