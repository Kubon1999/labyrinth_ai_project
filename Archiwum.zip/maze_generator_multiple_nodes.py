import dfs, bfs
import pygame, sys, random, globals, dijkstra_search
import copy, time, timeit

random.seed(None, 2)
globals.initialize()
#other
cells = []
map_dfs = []
map_bfs = []
map_dijkstra = []
global time_dfs, time_bfs, time_dijkstra
time_dfs = -1
time_bfs = -1
time_dijkstra = -1
pygame.init()
pygame.font.init() 
myfont = pygame.font.SysFont('Comic Sans MS', 30)
class Cell:
  def __init__(self, x, y):
    self.x = x
    self.y = y
    self.top = True
    self.right = True
    self.bottom = True
    self.left = True
    self.visited = False
    self.searched = False
    self.path = False 
    self.distance = float("inf")
    self.parent = 0 

  def show(self, my_offset_x, my_offset_y):
    position_x = self.x * globals.cell_size + my_offset_x
    position_y = self.y * globals.cell_size + my_offset_y
    EMPTY_COLOR = globals.GRAY

    if self.visited:
        pygame.draw.rect(globals.screen, EMPTY_COLOR, pygame.Rect(position_x, position_y, globals.cell_size, globals.cell_size))
    
    if self.searched:
        pygame.draw.rect(globals.screen, globals.BLUE, pygame.Rect(position_x, position_y, globals.cell_size, globals.cell_size))
        EMPTY_COLOR = globals.BLUE
    
    if self.path:
        pygame.draw.rect(globals.screen, globals.PURPLE, pygame.Rect(position_x, position_y, globals.cell_size, globals.cell_size))
        EMPTY_COLOR = globals.PURPLE

    if self == current:
        pygame.draw.rect(globals.screen, globals.RED, pygame.Rect(position_x, position_y, globals.cell_size, globals.cell_size))
    
    if self.x == globals.grid_w-1 and self.y == globals.grid_h-1:
        pygame.draw.rect(globals.screen, globals.GREEN, pygame.Rect(position_x, position_y, globals.cell_size, globals.cell_size))

    if not(self.top):
        pygame.draw.line(globals.screen, EMPTY_COLOR, (position_x,           position_y),                           (position_x+globals.cell_size, position_y),           globals.line_width) 
    if not(self.right):
        pygame.draw.line(globals.screen, EMPTY_COLOR, (position_x+globals.cell_size, position_y+globals.cell_size), (position_x, position_y+globals.cell_size),           globals.line_width)
    if not(self.bottom):
        pygame.draw.line(globals.screen, EMPTY_COLOR, (position_x+globals.cell_size, position_y+globals.cell_size), (position_x, position_y+globals.cell_size),           globals.line_width)
    if not(self.left):
        pygame.draw.line(globals.screen, EMPTY_COLOR, (position_x,           position_y+globals.cell_size),         (position_x, position_y),                             globals.line_width)


    if self.top:
        pygame.draw.line(globals.screen, globals.BLACK, (position_x,                   position_y),                   (position_x+globals.cell_size, position_y),                   globals.line_width)

    if self.right:
        pygame.draw.line(globals.screen, globals.BLACK, (position_x+globals.cell_size, position_y),                   (position_x+globals.cell_size, position_y+globals.cell_size), globals.line_width)            

    if self.bottom:
        pygame.draw.line(globals.screen, globals.BLACK, (position_x+globals.cell_size, position_y+globals.cell_size), (position_x, position_y+globals.cell_size),                   globals.line_width)

    if self.left:
        pygame.draw.line(globals.screen, globals.BLACK, (position_x,                   position_y+globals.cell_size), (position_x, position_y),                                     globals.line_width)
    

    
  def checkNeighbors(self):
    neighbors = []
    if Index(self.x, self.y-1) != -1:
        top = cells[Index(self.x, self.y-1)]
        if not(top.visited):
            neighbors.append(top)

    if Index(self.x+1, self.y) != -1:     
        right = cells[Index(self.x+1, self.y)]
        if not(right.visited):
            neighbors.append(right)

    if Index(self.x, self.y+1) != -1:
        bottom = cells[Index(self.x, self.y+1)]
        if not(bottom.visited):
            neighbors.append(bottom)
    
    if Index(self.x-1, self.y) != -1:
        left = cells[Index(self.x-1, self.y)]
        if not(left.visited):
            neighbors.append(left)
    
    if (len(neighbors) > 0):
        r = random.randint(0,len(neighbors)-1)
        return neighbors[r]
    else:
        return None 

#main function
def Setup():
    global current, stack
    InitGrid()
    current = cells[0]
    stack = []
    obieg = 0
    while True:
                
        #background
        #if the end of generation - create nodes
        if current == cells[0] and cells[1].visited == True:
            #generate_tree.drawTree(cells) 
            if obieg == 1:
                start_dfs = time.time()
                dfs_res = dfs.dfs(cells, cells[0])
                end_dfs = time.time()
                time_dfs = end_dfs - start_dfs
                print(time_dfs)
                saveMap(cells, map_dfs, globals.stats_dfs)
                if dfs_res:
                    start_bfs = time.time()
                    bfs.bfs(cells,cells[0])
                    end_bfs = time.time()
                    time_bfs = end_bfs - start_bfs
                    saveMap(cells, map_bfs, globals.stats_bfs)
                    #time.sleep(1000)
                    if globals.bfs_found_path:
                        start_dijkstra = time.time()
                        dijkstra_search.dijkstra(cells,cells[0])
                        end_dijkstra = time.time()
                        time_dijkstra = end_dijkstra - start_dijkstra
                        saveMap(cells, map_dijkstra, globals.stats_dijkstra)
                        break                                 
            
            if obieg == 0:
                # for cell in cells:
                #     cell.visited = False
                #usun 5 randomowych scian
                N_usuniec = int(len(cells) * 0.3)
                for i in range(N_usuniec):
                    temp = random.randrange(0, len(cells)-1)
                    print(cells[temp].x, cells[temp].y )
                    for cell in cells:
                        cell.visited = False
                    neighbor = cells[temp].checkNeighbors()
                    for cell in cells:
                        cell.visited = True
                    print(neighbor)
                    if neighbor:
                        RemoveWalls(cells[temp], neighbor)
                obieg = obieg + 1
                pygame.display.flip()
                print(obieg)
            
        
            #print(found)
            #print(found.x, found.y)
        #jestesmy  na ostatnim zakoncz zadanko i lec dalej drugim 
        # if current.x == globals.grid_w-1 and current.y == globals.grid_h-1:
        #     print("tak")
        #     current = cells[0]
        #     stack = []
        #update screen
        Draw()
    zrobione = False
    while True:
        for event in pygame.event.get():
            #wait for end 
            if event.type == pygame.QUIT:
                sys.exit(0)
        if not(zrobione):
            globals.screen.fill(globals.WHITE)
            showMap(map_dijkstra, "Dijkstra", globals.offset_map1, globals.stats_dijkstra, time_dijkstra)
            showMap(map_dfs, "DFS", globals.offset_map2, globals.stats_dfs, time_dfs)
            showMap(map_bfs, "BFS", globals.offset_map3, globals.stats_bfs, time_bfs)
            for cell in cells:
                cell.show(globals.offset, globals.offset)
            zrobione = True
            pygame.display.flip()
        #pygame.time.sleep(100000)

def InitGrid():
    for y in range(globals.grid_h):
        for x in range(globals.grid_w):
            cell = Cell(x,y)
            cells.append(cell)

def Draw():
    global current
    current.visited = True 

    #find next cell and mark it as visited
    next_current = current.checkNeighbors()
    if next_current:
        next_current.visited = True

        stack.append(current)
        #remove cells betweeen current and neighbor
        RemoveWalls(current, next_current)
        current = next_current
    elif len(stack) > 0:
        current = stack.pop()

def Index(x,y):
    if(x < 0 or y < 0 or x > globals.grid_w-1 or y > globals.grid_h -1):
        return -1
    return x + y * globals.grid_w

def RemoveWalls(current, neighbour):
    x_diff = current.x - neighbour.x
    #  |B|A| -- > |B A|
    if x_diff == 1:
        current.left = False
        neighbour.right = False
    #   |A|B| --> |A B| example a=46,b=47 a-b=-1
    elif x_diff == -1:
        current.right = False
        neighbour.left = False

    y_diff = current.y - neighbour.y   
    #  |A|        |A|
    #  |-|  --->  | |
    #  |B|        |B|
    if y_diff == 1:
        current.top = False
        neighbour.bottom = False
    elif y_diff == -1:
        current.bottom = False
        neighbour.top = False

def saveMap(cells, saveTo, stats):
    searched_cells = 0
    for cell in cells:
        temp = Cell(cell.x,cell.y)
        temp.top = cell.top
        temp.right = cell.right
        temp.bottom = cell.bottom
        temp.left = cell.left
        temp.visited =  cell.visited
        temp.searched =  cell.searched
        temp.path =  cell.path
        #temp = copy.deepcopy(cell)
        saveTo.append(temp)
        #reset cell
        cell.searched = False
        cell.path = False 
        cell.distance = float("inf")
        cell.parent = 0 

def showMap(map, title, offset, stats, time_spent):
    shortest_path = False
    searched_cells_count = 0
    cells_count = 0
    path_length = 0

    for cell in map:
        cell.show(offset, globals.offset)
        #save stats
        if cell.searched:
            searched_cells_count += 1
        cells_count = 0
        if cell.path:
            path_length += 1


    if title == "Dijkstra":
        globals.shortest_path = path_length
        shortest_path = True
    elif path_length <= globals.shortest_path:
        shortest_path = True

    print(title)
    stats.append(globals.algorithm_data(shortest_path, searched_cells_count, len(cells), path_length, time_spent))
    stats[-1].print()
    algorithm_name = myfont.render(title, False, (0, 0, 0)) 
    globals.screen.blit(algorithm_name,(offset, globals.offset_map1))

Setup()



